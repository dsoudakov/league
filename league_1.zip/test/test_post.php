<?php
require_once 'vendor/autoload.php';

$url = 'http://api.openweathermap.org/data/2.5/weather?q=toronto,ca&appid=2de143494c0b295cca9337e1e96b00e0';

$url = 'http://api.import.io/store/connector/a51bdad8-5a85-4ca8-a7b4-5cee2b617908/_query?format=JSON&_apikey=e773091e3fba442faca0329587cb3c429d409c0441d6a729b5a27b63c8e656447e8c0e82cfffc92a1ab2959d89e5e6aa0a1711629f2bbb123a9982b352d96cb7f42ab0d6f496cf4a923feaf750fef3ad';

$ch = curl_init($url);

curl_setopt($ch, CURLOPT_HTTPHEADER, array(
	"Content-Type: application/json",
));

curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);

$result = curl_exec($ch);
curl_close($ch);

var_dump($result);

die();

//$headers = array("Accept" => "application/json");
//$headers = array();
//$body = array();

$response = Unirest\Request::post($url);

$response->code;        // HTTP Status code
$response->headers;     // Headers
$response->body;        // Parsed body
$response->raw_body;    // Unparsed body

var_dump($response->body);

?>