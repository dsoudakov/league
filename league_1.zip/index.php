<?php
define('ROOT', __DIR__.DIRECTORY_SEPARATOR);

require_once ROOT . 'app/bootstrap.php';

$app->run();