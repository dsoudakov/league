<?php

require_once '../app/bootstrap.php';

$app->run();

